sap.ui.define([
	"sap/ui/core/mvc/Controller"
	], function (Controller) {
		"use strict";
		return Controller.extend("search.INV.controller.view1",{
			onSearchInv :function(){
				alert("Searching Invoices");
			}
		});
	});